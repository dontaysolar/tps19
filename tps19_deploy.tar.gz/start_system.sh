#!/bin/bash
cd /opt/tps19
python3 tps19_main.py
