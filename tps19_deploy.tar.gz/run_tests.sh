#!/bin/bash
cd /opt/tps19
python3 modules/testing/test_suite.py
