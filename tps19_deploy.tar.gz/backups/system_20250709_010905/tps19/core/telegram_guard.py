# Telegram command guard placeholder
def guard_command(cmd): return True
